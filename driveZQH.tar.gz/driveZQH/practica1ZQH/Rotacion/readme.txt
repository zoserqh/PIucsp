rotacion 11.25 grados sexagesimales
compilación: 		gcc -o bmpV1 bmpV1.c
ejm de ejecución:	./bmpV1 linux_detergente.bmp -x1
imagen de salida:	tratada.bmp
