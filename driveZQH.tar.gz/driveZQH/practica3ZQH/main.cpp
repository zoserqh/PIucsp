#include<iostream>
#include <stdlib.h>
using namespace std;

main(){
	
	cout<<"xD"<<endl;
	system("g++ -Wall -o fft fft.cpp `pkg-config --cflags --libs opencv`");
	system("./fft");
	system("./fft text.png");
	system("./fft textRot.png");
	return 0;
}
