freq=0.1;
%i=1:9;
ii=0:1:511;
%a=[1 2 3 2 1 2 3 2 1];
%b=[17 + 0j,-1.152704 - 0.41955j,-3.379385 - 2.835641j,0.5 + 0.866025j,0.032089 + 0.181985j,0.032089 - 0.181985j,0.5 - 0.866025j,-3.379385 + 2.835641j,-1.152704 + 0.41955j];
%b=abs(b);
%c=[0 0 0 1 1 0 0 0 0];
%cT=[2 + 0j,-1.439693 - 1.208046j,0.266044 + 1.508813j,0.5 - 0.866025j,-0.326352 + 0.118782j,-0.326352 - 0.118782j,0.5 + 0.866025j,0.266044 - 1.508813j,-1.439693 + 1.208046j];
%cT=abs(cT);

d=sin(2*pi*freq*ii)+sin(2*pi*2*freq*ii);
dT=zeros(1,512);
dTO=fft(d);
dTO=abs(dTO);
for k=1:512
  for j=1:512
    dT(k)=dT(k)+d(j)*exp(i*2*pi*j*k/(size+1));
  endfor
endfor

dT=abs(dT);

figure
hold on
plot(ii,dT,'r')
plot(ii,dTO,'b')

%{
figure
plot(i,a)

figure
plot(i,b)

figure
hold on
plot(i,c)
plot(i,cT)
%}